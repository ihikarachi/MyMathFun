# MyMathFun

Developed by Shakeel Abbas from imam Hussain (a.s) institute Karachi (c) 2023

## Examples of How To Use 

```python
from MyMathFun import mySum
from MyMathFun import mySub
from MyMathFun import myMul
from MyMathFun import myDiv

x = mySum(3,4)
print(x)

x = mySub(3,4)
print(x)

x = myDiv(3,4)
print(x)

x = myMul(3,4)
print(x)

```


Check out: https://www.youtube.com/@imamHussainasinstitute
