from .code import mySub
from .code import mySum
from .code import myDiv
from .code import myMul