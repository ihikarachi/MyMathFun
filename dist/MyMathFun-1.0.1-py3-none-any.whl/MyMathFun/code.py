def mySum (a,b):
    return a+b

def mySub (a,b):
    return a-b

def myMul (a,b):
    return (a*b)

def myDiv (a,b):
    return  a/b